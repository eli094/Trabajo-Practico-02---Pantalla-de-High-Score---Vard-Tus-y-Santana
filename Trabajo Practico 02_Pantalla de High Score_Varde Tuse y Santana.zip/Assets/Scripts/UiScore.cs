using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UiScore : MonoBehaviour
{
    [SerializeField] private List<UiScoreItem> items = new List<UiScoreItem>();

    [SerializeField] private UiScoreItem scoreItemPrefab;

    [SerializeField] private Transform content;

    [SerializeField] TMP_InputField nameInput;
    [SerializeField] TMP_InputField scoreInput;

    [SerializeField] Button confirmButton;

    private int maxElements = 10;

    private void Awake()
    {
        confirmButton.onClick.AddListener(OnConfirmClicked);
    }

    private void Start()
    {
        for (int i = 0; i < maxElements; i++)
        {
            string randomScore = Random.Range(0, 1000).ToString();
            AddPlayer(i.ToString(), "Player", randomScore);
        }
    }

    private void OnDestroy()
    {
        confirmButton.onClick.RemoveAllListeners();
    }

    private void OnConfirmClicked()
    {
        string playerName = nameInput.text;
        string playerScore = scoreInput.text;

        AddPlayer("xx", playerName, playerScore);

        nameInput.text = "";
        scoreInput.text = "";

    }

    private void Sort(string score, UiScoreItem uiScoreItem)
    {
         for(int i = 0; i < items.Count; i++)
         {

            if (int.Parse(score) > int.Parse(items[i].scoreText.text))
            {
                int siblingIndex = items[i].transform.GetSiblingIndex();

                uiScoreItem.transform.SetSiblingIndex(siblingIndex);

                items.RemoveAt(items.Count - 1);
                items.Insert(i, uiScoreItem);

                return;
            }
         }
    }

    void AddPlayer(string number, string name, string score)
    {
        UiScoreItem item = Instantiate(scoreItemPrefab, content);

        item.Set(number, name, score);
        items.Add(item);

        Sort(score, item);
    }
}
