using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class UiScoreItem : MonoBehaviour
{
    [SerializeField] public TMP_Text numberText;
    [SerializeField] public TMP_Text nameText;
    [SerializeField] public TMP_Text scoreText;

    public void Set(string number, string name, string score)
    {
       numberText.text = number;
       nameText.text = name;
       scoreText.text = score;
    }

    public void SetNumber(string score)
    {
        numberText.text = score;
    }

    public void Update()
    {
        int rewriteIndex  = transform.GetSiblingIndex();

        numberText.text = rewriteIndex.ToString();
    }
}
